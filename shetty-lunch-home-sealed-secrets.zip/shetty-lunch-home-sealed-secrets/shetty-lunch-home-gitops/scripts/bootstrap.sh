#!/usr/bin/env bash
# One-time cluster bootstrap (SEALED SECRETS edition):
#   kind cluster + ingress-nginx + Sealed Secrets controller + ArgoCD + AppProject.
# It deliberately does NOT start the GitOps sync. You must first seal the secrets with THIS cluster's key
# (./scripts/seal-secrets.sh all), push them to git, and only then apply argocd/root-app.yaml (README step 8).
# Run from the GitOps repo root:  ./scripts/bootstrap.sh      Windows: use WSL2 or Git Bash.
set -euo pipefail
cd "$(dirname "$0")/.."

for bin in docker kind kubectl helm kubeseal openssl; do
  command -v "$bin" >/dev/null || { echo "ERROR: '$bin' is not installed (see README prerequisites)"; exit 1; }
done

if grep -rq "YOUR_GITHUB_USERNAME" argocd overlays base; then
  echo "ERROR: placeholder YOUR_GITHUB_USERNAME is still present."
  echo "       Run ./scripts/replace-placeholders.sh <github-username> from the project root first (README step 2)."
  exit 1
fi

echo ">>> 1/5 Creating kind cluster 'slh' (skipped if it exists)"
if kind get clusters | grep -qx slh; then
  echo "cluster already exists"
else
  kind create cluster --config scripts/kind-config.yaml
fi
kubectl config use-context kind-slh

echo ">>> 2/5 Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl wait --namespace ingress-nginx --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller --timeout=240s

echo ">>> 3/5 Installing the Sealed Secrets controller (kube-system)"
# fullnameOverride makes the controller name match what the kubeseal CLI looks for by default.
helm repo add sealed-secrets https://bitnami-labs.github.io/sealed-secrets >/dev/null 2>&1 || true
helm repo update >/dev/null
helm upgrade --install sealed-secrets sealed-secrets/sealed-secrets \
  --namespace kube-system --set fullnameOverride=sealed-secrets-controller --wait --timeout 5m

echo ">>> 4/5 Installing ArgoCD"
kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -
# --server-side: the ArgoCD CRDs are too large for client-side apply
kubectl apply -n argocd --server-side --force-conflicts \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl -n argocd rollout status deployment/argocd-server --timeout=300s
kubectl -n argocd rollout status deployment/argocd-repo-server --timeout=300s

echo ">>> 5/5 Applying the AppProject"
kubectl apply -f argocd/project.yaml

PASS=$(kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d)
cat <<EOF

Cluster is ready. NEXT (README step 8):
  1. ./scripts/seal-secrets.sh all          # creates overlays/<env>/sealed-secret.yaml (safe to commit)
  2. ./scripts/backup-sealing-key.sh        # keep the private key OUTSIDE git
  3. git pull --rebase && git add . && git commit -m "add sealed secrets" && git push
  4. kubectl apply -f argocd/root-app.yaml  # starts the GitOps sync

ArgoCD UI : kubectl -n argocd port-forward svc/argocd-server 8443:443  ->  https://localhost:8443
Username  : admin
Password  : ${PASS}

Hosts file entry:
  127.0.0.1 dev.shettylunchhome.local staging.shettylunchhome.local prod.shettylunchhome.local
EOF
