#!/usr/bin/env bash
# Exports the Sealed Secrets PRIVATE key(s) so you can restore them if the cluster is rebuilt.
# Without this key, every sealed-secret.yaml in git becomes undecryptable and must be re-sealed.
#
# !!! The output file contains the private key. NEVER commit it. Real companies store it in a vault / password manager. !!!
#
#   ./scripts/backup-sealing-key.sh [output-file]
# Restore on a new cluster (after installing the controller):
#   kubectl apply -f <output-file> && kubectl -n kube-system rollout restart deploy/sealed-secrets-controller
set -euo pipefail
OUT="${1:-sealed-secrets-master-key.backup.yaml}"
umask 077
kubectl -n kube-system get secret -l sealedsecrets.bitnami.com/sealed-secrets-key -o yaml > "$OUT"
if ! grep -q 'tls.key' "$OUT"; then rm -f "$OUT"; echo "ERROR: no sealing key found (is the controller running?)"; exit 1; fi
echo "Saved private sealing key to $OUT (permissions 600)."
echo "Store it OUTSIDE git. It is already covered by .gitignore in this repo."
