#!/usr/bin/env bash
# Generates STRONG RANDOM secrets for an environment, encrypts them with the cluster's public key
# (kubeseal) and writes overlays/<env>/sealed-secret.yaml. The sealed file is safe to commit to git.
# The plain values are never written to disk and never printed.
#
#   ./scripts/seal-secrets.sh dev        one environment
#   ./scripts/seal-secrets.sh all        dev + staging + prod (each gets DIFFERENT passwords)
#   FORCE=1 ./scripts/seal-secrets.sh dev   regenerate an existing one (see README: rotation warning!)
set -euo pipefail
cd "$(dirname "$0")/.."

TARGET="${1:?usage: $0 <dev|staging|prod|all>}"
for bin in kubectl kubeseal openssl; do
  command -v "$bin" >/dev/null || { echo "ERROR: '$bin' is not installed"; exit 1; }
done
CTRL_NAME=sealed-secrets-controller
CTRL_NS=kube-system
kubectl -n "$CTRL_NS" get deploy "$CTRL_NAME" >/dev/null 2>&1 || {
  echo "ERROR: Sealed Secrets controller not found in this cluster. Run ./scripts/bootstrap.sh first."; exit 1; }

seal_env() {
  local env="$1" ns="slh-$1" out="overlays/$1/sealed-secret.yaml"
  [ -d "overlays/$env" ] || { echo "ERROR: unknown environment '$env'"; exit 1; }
  if [ -f "$out" ] && [ "${FORCE:-0}" != "1" ]; then
    echo "SKIP  $env: $out already exists (use FORCE=1 to regenerate - read the README rotation warning first)"
    return
  fi
  local db_pass jwt
  db_pass=$(openssl rand -base64 24 | tr -d '/+=\n')
  jwt=$(openssl rand -hex 32)

  # Sealed with the default "strict" scope: the result only decrypts as Secret "slh-secrets" in namespace $ns.
  kubectl create secret generic slh-secrets --namespace "$ns" \
    --from-literal=DB_USER=slhadmin \
    --from-literal=DB_PASSWORD="$db_pass" \
    --from-literal=JWT_SECRET="$jwt" \
    --dry-run=client -o yaml \
  | kubeseal --controller-name "$CTRL_NAME" --controller-namespace "$CTRL_NS" --format yaml > "$out.tmp"
  mv "$out.tmp" "$out"

  # make the overlay include the sealed file (idempotent)
  if ! grep -q 'sealed-secret.yaml' "overlays/$env/kustomization.yaml"; then
    awk '{print} /^  - \.\.\/\.\.\/base$/ {print "  - sealed-secret.yaml"}' "overlays/$env/kustomization.yaml" > "overlays/$env/kustomization.yaml.tmp"
    mv "overlays/$env/kustomization.yaml.tmp" "overlays/$env/kustomization.yaml"
  fi
  echo "OK    $env: wrote $out (encrypted for namespace $ns)"
}

if [ "$TARGET" = "all" ]; then
  for e in dev staging prod; do seal_env "$e"; done
else
  seal_env "$TARGET"
fi
echo
echo "Next: ./scripts/backup-sealing-key.sh, then git add/commit/push. NEVER commit anything except sealed-secret.yaml."
