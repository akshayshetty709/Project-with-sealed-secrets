# 🍛 Shetty Lunch Home — Food Delivery Microservices on Kubernetes with GitOps (ArgoCD) — Sealed Secrets edition

A complete, practice-ready DevOps project that follows the flow real IT companies use:
**code → pull request → CI (test, scan, build image) → container registry → GitOps repo → ArgoCD → Kubernetes (dev → staging → prod) → PostgreSQL**.

Everything is here: 4 microservices + web frontend, a database per service, Dockerfiles, docker-compose,
GitHub Actions CI, a separate GitOps repo with Kustomize overlays for three environments, ArgoCD
(app-of-apps, manual gate for prod), scripts, and this guide.

> ## 🔐 Edition: **Sealed Secrets** (secrets encrypted inside git)
> This is the practice project with the plain `base/secret.yaml` **removed** and replaced by encrypted `SealedSecret` files, the way many
> small and mid-size teams run GitOps. Differences from the basic project: **step 8 is split into 8a–8d** (the cluster must exist before you can
> seal), new scripts `seal-secrets.sh` and `backup-sealing-key.sh`, a gitleaks job in CI, and a full chapter on the topic: **[section 9](#9-secrets-management-with-sealed-secrets)**.
> The sibling zip `shetty-lunch-home-external-secrets` shows the large-company alternative (External Secrets Operator + a vault).
>
> *Testing status of what is new in this edition:* `seal-secrets.sh` was run against stubbed `kubectl`/`kubeseal` (idempotence, per-environment output,
> overlay editing, no plain text on disk) and every YAML/cross-reference was validated. The Helm install of the controller, real `kubeseal` encryption and the
> ArgoCD sync were **not** run (no cluster/network in the sandbox) — follow the troubleshooting table if something differs.

> **Read this first — what has and has not been tested (basic project).**
> The project was generated in a sandbox without a Docker daemon, a Kubernetes cluster or access to the npm
> registry. What *was* verified: all JavaScript parses, all 23 YAML files parse, every cross-reference
> (service ports ↔ nginx ↔ ConfigMap URLs ↔ probes ↔ secret keys ↔ image names ↔ overlays ↔ ArgoCD apps ↔ CI matrix)
> is consistent, and the placeholder/promotion scripts work on a copy. What was **not** run: container builds,
> `docker compose up`, the CI pipeline, the cluster deployment. So you may hit a small snag on first run — that is
> normal in real DevOps work and the [Troubleshooting](#14-troubleshooting) section is written for exactly that.

---

## Table of contents

1. [What you are building](#1-what-you-are-building)
2. [How a real company's flow works (and how this project maps to it)](#2-how-a-real-companys-flow-works)
3. [Project layout](#3-project-layout)
4. [Changes YOU must make](#4-changes-you-must-make-checklist)
5. [Prerequisites](#5-prerequisites)
6. [Step-by-step deployment](#6-step-by-step-deployment)
7. [Practice scenarios (do these — this is where you learn)](#7-practice-scenarios)
8. [Database: how it works and how it changes in real life](#8-database)
9. [Secrets management with Sealed Secrets](#9-secrets-management-with-sealed-secrets)
10. [Moving from your laptop to a real cloud](#10-moving-to-a-real-cloud)
11. [Production hardening checklist / what to add next](#11-production-hardening-checklist)
12. [API reference](#12-api-reference)
13. [Cleanup](#13-cleanup)
14. [Troubleshooting](#14-troubleshooting)
15. [Interview talking points](#15-interview-talking-points)

---

## 1. What you are building

### Application (domain: online food ordering)

| Component | Port | Database | Responsibility |
|---|---|---|---|
| `frontend` (nginx) | 8080 (Service: 80) | – | Web UI + single public entry point; reverse-proxies `/api/users`, `/api/restaurants`, `/api/orders` |
| `user-service` | 3001 | `userdb` | Sign up, login (bcrypt + JWT), profile |
| `restaurant-service` | 3002 | `restaurantdb` | Restaurants + menus (seeded with coastal Karnataka restaurants); internal price lookup |
| `order-service` | 3003 | `orderdb` | Places orders: validates JWT, **re-prices items from restaurant-service**, saves order, calls payment-service |
| `payment-service` | 3004 | `paymentdb` | Simulated payment gateway (COD/UPI/CARD). Internal only — not reachable from the internet |
| `postgres` (StatefulSet) | 5432 | 4 databases | One server, **one database per microservice** |

### Architecture

```mermaid
flowchart LR
  U[Browser] -->|dev.shettylunchhome.local| ING[Ingress NGINX]
  ING --> FE[frontend nginx]
  FE -->|/api/users| US[user-service]
  FE -->|/api/restaurants| RS[restaurant-service]
  FE -->|/api/orders| OS[order-service]
  OS -->|price lookup| RS
  OS -->|take payment| PS[payment-service]
  US --> DB1[(userdb)]
  RS --> DB2[(restaurantdb)]
  OS --> DB3[(orderdb)]
  PS --> DB4[(paymentdb)]
  subgraph PG[PostgreSQL StatefulSet + PVC]
    DB1
    DB2
    DB3
    DB4
  end
```

### DevOps toolchain

| Concern | Tool | Where in this project |
|---|---|---|
| Source control | Git + GitHub | two repos (app, gitops) |
| CI | GitHub Actions | `shetty-lunch-home-app/.github/workflows/ci.yml` |
| Container build | Docker (multi-stage, non-root) | `services/*/Dockerfile` |
| Registry | GitHub Container Registry (ghcr.io) | `ghcr.io/<you>/slh-<service>:sha-xxxxxxx` |
| Security scan | Trivy (report-only) | CI job `security-scan` |
| Config management | Kustomize (base + overlays) | `shetty-lunch-home-gitops/base`, `overlays/*` |
| Secrets | Sealed Secrets controller + `kubeseal` (encrypted secrets in git) + gitleaks scan | `overlays/*/sealed-secret.yaml`, `scripts/seal-secrets.sh` |
| CD / GitOps | ArgoCD (app-of-apps) | `shetty-lunch-home-gitops/argocd/*` |
| Orchestration | Kubernetes (kind locally) | `scripts/kind-config.yaml` |
| Ingress | ingress-nginx | installed by `scripts/bootstrap.sh` |
| Database | PostgreSQL 16 + PVC | `base/postgres.yaml` |
| Autoscaling / availability | HPA + PodDisruptionBudget (prod only) | `overlays/prod/` |

---

## 2. How a real company's flow works

**Golden rule of GitOps: Git is the single source of truth. Nobody (including CI) runs `kubectl apply` against the
cluster. CI only *changes git*; ArgoCD, running inside the cluster, *pulls* from git and makes the cluster match.**

```
Developer ──PR──► app repo (main) ──► GitHub Actions
                                         1. test (unit tests, syntax)
                                         2. trivy security scan
                                         3. docker build + push  ghcr.io/<you>/slh-*:sha-1a2b3c4
                                         4. commit new tag into GitOps repo  overlays/dev/kustomization.yaml
                                                          │
                              GitOps repo (main) ◄────────┘
                                   │  ArgoCD polls git (every ~3 min, or instantly via webhook)
                                   ▼
                  ┌────────── Kubernetes cluster ──────────┐
 dev     (auto)   │ slh-dev      ← ArgoCD app slh-dev      │  auto-sync, self-heal, prune
 staging (auto)   │ slh-staging  ← ArgoCD app slh-staging  │  changes only via promotion PR
 prod  (MANUAL)   │ slh-prod     ← ArgoCD app slh-prod     │  PR + approval, then a human presses SYNC
                  └────────────────────────────────────────┘
```

**Why two repos?** The app repo changes many times a day (every feature); the GitOps repo changes only when a
*deployment* happens. Separate repos give: clean audit trail of "who deployed what, when" (`git log` of the GitOps repo),
different permissions (developers can't silently change prod), and no CI loops (a CI commit to the app repo would
re-trigger CI).

**Promotion** = editing the image tag in the next environment's overlay through a pull request
(`scripts/promote.sh`). **Rollback** = `git revert` in the GitOps repo (or ArgoCD → History → Rollback for an emergency).

**Environment differences** (all in git, all visible in `overlays/`):

| | dev | staging | prod |
|---|---|---|---|
| Namespace | `slh-dev` | `slh-staging` | `slh-prod` |
| Hostname | `dev.shettylunchhome.local` | `staging.shettylunchhome.local` | `prod.shettylunchhome.local` |
| Replicas | 1 each | 2 each | 2 each; `order-service` autoscaled 2–5 (HPA) |
| Image tag updated by | CI bot (automatic) | promotion PR | promotion PR + approval |
| ArgoCD sync | automatic | automatic | **manual** |
| Extras | – | – | HPA, PodDisruptionBudgets |

---

## 3. Project layout

```
shetty-lunch-home/
├── README.md                          ← this file
├── scripts/
│   └── replace-placeholders.sh        ← puts your GitHub username into both repos (step 2)
│
├── shetty-lunch-home-app/             ← REPO 1: application source + CI   (you push this to GitHub)
│   ├── docker-compose.yml             ← run everything locally with one command
│   ├── db/init.sql                    ← creates the 4 databases (local)
│   ├── .github/workflows/ci.yml       ← test → scan → build/push → update GitOps repo
│   └── services/
│       ├── user-service/              ← server.js, package.json, Dockerfile, test/
│       ├── restaurant-service/
│       ├── order-service/
│       ├── payment-service/
│       └── frontend/                  ← index.html, nginx.conf, Dockerfile
│
└── shetty-lunch-home-gitops/          ← REPO 2: desired state of the cluster   (you push this too)
    ├── base/                          ← manifests shared by all environments
    │   ├── postgres.yaml              ← StatefulSet + PVC + headless Service
    │   ├── configmap.yaml                     ← (no Secret in base any more - see section 9)
    │   ├── user-service.yaml … frontend.yaml   ← Deployment + Service each
    │   └── ingress.yaml
    ├── overlays/
    │   ├── dev/kustomization.yaml     ← namespace, image tags (CI edits), host, replicas
    │   ├── staging/kustomization.yaml
    │   └── prod/ (kustomization.yaml, hpa.yaml, pdb.yaml)
    ├── argocd/
    │   ├── project.yaml               ← AppProject (allowed repo + namespaces)
    │   ├── root-app.yaml              ← app-of-apps (applied once by hand)
    │   └── apps/ dev.yaml, staging.yaml, prod.yaml
    └── scripts/
        ├── kind-config.yaml           ← local cluster with ports 80/443 mapped
        ├── bootstrap.sh               ← cluster + ingress-nginx + Sealed Secrets controller + ArgoCD + project (no sync yet)
        ├── seal-secrets.sh            ← generate random secrets + encrypt → overlays/<env>/sealed-secret.yaml
        ├── backup-sealing-key.sh      ← export the controller's PRIVATE key (never commit)
        └── promote.sh                 ← dev→staging→prod tag promotion
```

---

## 4. Changes YOU must make (checklist)

| # | Change | Where | Why |
|---|---|---|---|
| 1 | Replace `YOUR_GITHUB_USERNAME` with your username | **All files**, done by `./scripts/replace-placeholders.sh <username>` | Image paths (`ghcr.io/<you>/…`) and ArgoCD repo URLs |
| 2 | Create **two** GitHub repos named exactly `shetty-lunch-home-app` and `shetty-lunch-home-gitops` | GitHub | CI checks out `<owner>/shetty-lunch-home-gitops`. If you choose other names, edit `repository:` in `ci.yml` and the `repoURL`s in `argocd/` |
| 3 | Create a fine-grained **Personal Access Token** and store it as secret **`GITOPS_PAT`** in the *app* repo | GitHub → Settings | Lets CI commit the new image tag into the GitOps repo |
| 4 | Make the 5 container packages **public** (or add an imagePullSecret) | GitHub → Packages | ghcr packages are private by default; the cluster can't pull private images without credentials |
| 5 | Keep the GitOps repo **public** (or give ArgoCD credentials) | GitHub / ArgoCD | ArgoCD must be able to clone it |
| 6 | Add 3 hostnames to your hosts file | `/etc/hosts` (Windows: `C:\Windows\System32\drivers\etc\hosts`) | So `dev.shettylunchhome.local` etc. resolve to your machine |
| 7 | *(recommended)* Generate `package-lock.json` in each service | `npm install` in each `services/*` | Reproducible builds; Dockerfile and CI automatically switch to `npm ci` when the lockfile exists |
| 8 | Nothing to type, but you **must** run `./scripts/seal-secrets.sh all` after the cluster exists (step 8b), **back up the key** (8c) and commit the three `sealed-secret.yaml` files | `shetty-lunch-home-gitops` | This replaces the practice passwords with random, per-environment, encrypted ones. See [section 9](#9-secrets-management-with-sealed-secrets) |
| 9 | *(optional)* Port 80 busy? Change `hostPort: 80` → `8081` | `scripts/kind-config.yaml` | Then browse `http://dev.shettylunchhome.local:8081` |
| 10 | *(optional)* Use Docker Hub / AWS ECR instead of ghcr | `ci.yml` login step + image names in `base/*.yaml` and `overlays/*` | Only if your company/learning goal uses another registry |

---

## 5. Prerequisites

| Tool | Used for | Check |
|---|---|---|
| Git | version control | `git --version` |
| GitHub account | repos, Actions, container registry | – |
| Docker Desktop / Docker Engine | build images, run kind & compose (give Docker **≥ 6 GB RAM**) | `docker version` |
| `kubectl` | talk to the cluster | `kubectl version --client` |
| `kind` | local Kubernetes in Docker | `kind version` |
| `helm` | installs the Sealed Secrets controller | `helm version` |
| `kubeseal` | encrypts secrets (install from the [sealed-secrets releases](https://github.com/bitnami-labs/sealed-secrets/releases) page, or `brew install kubeseal`) | `kubeseal --version` |
| `openssl` | random secret generation (preinstalled on Linux/macOS/WSL) | `openssl version` |
| Node.js 20+ and npm | generate lockfiles, run tests locally (optional) | `node -v` |
| GitHub CLI `gh` *(optional)* | create repos from terminal | `gh --version` |
| `argocd` CLI *(optional)* | sync/rollback from terminal | `argocd version --client` |

**Windows:** run all shell scripts in **WSL2** (recommended) or Git Bash.

**RAM note:** three environments × (5 services + Postgres) is ~20+ pods. If your machine is small, delete
`argocd/apps/prod.yaml` (and `staging.yaml`) before step 8 and add them back later when you practise promotion.

---

## 6. Step-by-step deployment

### Step 1 — Unzip and look around
```bash
unzip shetty-lunch-home.zip
cd shetty-lunch-home
ls
```

### Step 2 — Put your GitHub username in the project
```bash
./scripts/replace-placeholders.sh <your-github-username>
# example: ./scripts/replace-placeholders.sh akshay-shetty
```
This lower-cases the name (registry paths must be lowercase) and replaces every `YOUR_GITHUB_USERNAME`.
Verify nothing is left (only this README and the script itself mention the word):
```bash
grep -rl YOUR_GITHUB_USERNAME . || echo "all replaced"
```

### Step 3 — (Recommended) Generate lockfiles
```bash
for s in user-service restaurant-service order-service payment-service; do (cd shetty-lunch-home-app/services/$s && npm install); done
```
This creates `package-lock.json` in each service. Commit them. (Also lets you run `npm test` locally.)

### Step 4 — Smoke-test locally with Docker Compose (before any cloud/GitOps)
```bash
cd shetty-lunch-home-app
docker compose up --build
```
Open **http://localhost:8080**: sign up, log in, open a restaurant, add items, place an order (try UPI and COD).
Or use the [curl examples](#12-api-reference). Stop with `Ctrl+C`; `docker compose down -v` also deletes the DB volume.

If this works, your application and Dockerfiles are good. Always do this before debugging Kubernetes.

### Step 5 — Create the two GitHub repos and push (GitOps repo FIRST)
Order matters: CI will push to the GitOps repo's `main` branch, so it must exist first.

```bash
# --- GitOps repo ---
cd shetty-lunch-home/shetty-lunch-home-gitops
git init -b main
git add . && git commit -m "initial gitops config"
gh repo create shetty-lunch-home-gitops --public --source=. --remote=origin --push

# --- App repo ---
cd ../shetty-lunch-home-app
git init -b main
git add . && git commit -m "initial application code"
gh repo create shetty-lunch-home-app --public --source=. --remote=origin
# DON'T push yet - configure secrets first (step 6), otherwise the first CI run fails at the last job.
```
No `gh`? Create the empty repos in the GitHub web UI, then `git remote add origin https://github.com/<you>/<repo>.git && git push -u origin main`.

### Step 6 — GitHub configuration

**6a. Token for CI → GitOps repo** (`GITOPS_PAT`)
1. GitHub → *Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token*.
2. Resource owner: you. Repository access: **Only select repositories → `shetty-lunch-home-gitops`**.
3. Permissions → Repository permissions → **Contents: Read and write**. Generate and copy the token.
4. In the **app** repo: *Settings → Secrets and variables → Actions → New repository secret* → name **`GITOPS_PAT`**, paste the token.

`GITHUB_TOKEN` (used to push images) is provided automatically; nothing to create.

**6b. Allow Actions to publish packages:** app repo → *Settings → Actions → General → Workflow permissions* → keep "Read and write permissions" (the workflow also requests `packages: write` itself).

### Step 7 — Run CI for the first time
```bash
cd shetty-lunch-home-app
git push -u origin main
```
GitHub → app repo → **Actions** tab. You should see: `test` ×4 → `security scan` + `secret scan (gitleaks)` → `build & push` ×5 → `update GitOps repo (dev)`.

Check the results:
* *Your profile → Packages*: five packages `slh-user-service`, `slh-restaurant-service`, `slh-order-service`, `slh-payment-service`, `slh-frontend`, each with tags `sha-xxxxxxx` and `latest`.
* GitOps repo → commits: a commit from `slh-ci-bot` — *"ci: deploy sha-xxxxxxx to dev"* — and `overlays/dev/kustomization.yaml` now has `newTag: sha-xxxxxxx` for all five images.

**Make the packages public** (for each of the 5): *Profile → Packages → package → Package settings → Danger Zone → Change visibility → Public.*
(Alternative for private packages: create an `imagePullSecret` — see [Troubleshooting](#14-troubleshooting) → ImagePullBackOff.)

### Step 8 — Create the cluster, install ArgoCD and the Sealed Secrets controller

> **Order matters in this edition.** A sealed secret can only be created *after* the cluster exists (the cluster owns the
> encryption key), and ArgoCD must only start syncing *after* the sealed files are in git. So Step 8 has four parts: 8a → 8d.

**8a. Bootstrap the cluster**
```bash
cd shetty-lunch-home/shetty-lunch-home-gitops
git pull --rebase origin main        # CI may already have committed a new image tag
./scripts/bootstrap.sh
```
It creates the kind cluster `slh`, installs ingress-nginx, installs the **Sealed Secrets controller** (Helm, namespace `kube-system`),
installs ArgoCD and applies the AppProject. It does **not** start the GitOps sync yet, and it prints the ArgoCD admin password.

Add the hostnames to your hosts file:
```
127.0.0.1 dev.shettylunchhome.local staging.shettylunchhome.local prod.shettylunchhome.local
```
Open the ArgoCD UI when you want to look around (nothing is deployed yet):
```bash
kubectl -n argocd port-forward svc/argocd-server 8443:443
# browse https://localhost:8443  (accept the self-signed cert)  user: admin  password: printed by bootstrap.sh
# lost the password?  kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d
```

**8b. Seal the secrets — the heart of this edition**
```bash
./scripts/seal-secrets.sh all
```
For each of dev / staging / prod this script: generates a random DB password and a random JWT secret → builds a Kubernetes Secret
**in memory only** → encrypts it with the cluster's public key (`kubeseal`) → writes `overlays/<env>/sealed-secret.yaml` → adds that file to the
overlay's `kustomization.yaml`. Plain values are never written to disk or printed. Look at the result:
```bash
cat overlays/dev/sealed-secret.yaml        # long encrypted strings - this file is SAFE to commit
git status                                  # 3 new sealed-secret.yaml files + 3 modified kustomization.yaml
```
Each environment gets **different** passwords, and each sealed file only decrypts in its own namespace (`slh-dev`, `slh-staging`, `slh-prod`).

**8c. Back up the private key, then commit and push**
```bash
./scripts/backup-sealing-key.sh            # writes sealed-secrets-master-key.backup.yaml  (PRIVATE - never commit; .gitignore blocks it)
# store that file somewhere safe OUTSIDE git (password manager / encrypted drive), then:
git pull --rebase origin main
git add overlays
git commit -m "add sealed secrets for dev, staging and prod"
git push origin main
```

**8d. Start GitOps**
```bash
kubectl apply -f argocd/root-app.yaml
kubectl -n argocd get applications -w
```
The controller decrypts each `SealedSecret` into the normal Secret `slh-secrets` in its namespace, and the Deployments/Postgres read it exactly like before.
Verify:
```bash
kubectl -n slh-dev get sealedsecret                         # SYNCED = True
kubectl -n slh-dev get secret slh-secrets                   # created by the controller, not by you
kubectl -n slh-dev get secret slh-secrets -o jsonpath='{.data.DB_USER}' | base64 -d   # slhadmin  (only check the non-sensitive key)
```

### Step 9 — Watch GitOps happen
```bash
kubectl -n argocd get applications -w
```
Within a minute or two you will see `slh-root` → `Synced`, then `slh-dev` and `slh-staging` → `Synced/Healthy`,
and `slh-prod` → **OutOfSync** (that is correct: prod waits for a human).

```bash
kubectl -n slh-dev get sealedsecret,secret slh-secrets   # SealedSecret SYNCED + the Secret the controller created
kubectl -n slh-dev get pods            # postgres-0 + 5 services, all Running / Ready
kubectl -n slh-dev logs deploy/order-service
kubectl -n slh-dev get ingress
```
Open **http://dev.shettylunchhome.local** and use the app. (Without editing hosts you can test with
`curl -H "Host: dev.shettylunchhome.local" http://localhost/api/restaurants`.)

Deploy prod once by hand: ArgoCD UI → `slh-prod` → **SYNC** → **SYNCHRONIZE** (or `argocd app sync slh-prod`). Then browse
http://prod.shettylunchhome.local.

> **How fast is "automatic"?** ArgoCD polls git about every 3 minutes. To see changes instantly click **REFRESH** in the UI,
> or configure a GitHub webhook to ArgoCD (what companies do).

---

## 7. Practice scenarios

Do these in order. Each one is a normal day-to-day DevOps task.

### A. Ship a feature through the whole pipeline
1. In the app repo create a branch, change the tagline in `services/frontend/index.html`, commit, push, open a **pull request**.
   CI runs `test` + `scan` only (nothing deploys from a PR).
2. Merge the PR → CI builds new images tagged `sha-<new>` → bot commits the tag to GitOps `overlays/dev`.
3. Watch ArgoCD roll out dev (`kubectl -n slh-dev get pods -w`). Refresh the dev site: new tagline.
   Staging and prod still show the old one — that is the point.

### B. Promote dev → staging → prod
```bash
cd shetty-lunch-home-gitops && git pull
./scripts/promote.sh dev staging
git checkout -b promote-staging && git add overlays/staging && git commit -m "promote to staging" && git push -u origin promote-staging
# open PR on GitHub → review → merge → ArgoCD auto-syncs staging
./scripts/promote.sh staging prod        # after testing staging
# PR (+ approval in a real company) → merge → ArgoCD shows slh-prod OutOfSync → a human presses SYNC
```
Turn on **branch protection** for `main` of the GitOps repo (require PR + 1 approval) to model the real prod gate.
(For the CI bot to still push to `main`, allow your bot/PAT to bypass, or let CI open a PR instead — a common variation.)

### C. Roll back a bad release
1. Introduce a bug: in `order-service/server.js` add `throw new Error('boom')` at the top of the file, push to `main`.
2. CI builds and bot deploys it to dev. The new pod crashes / never becomes Ready; **the old pods keep serving traffic** (rolling update + readiness probes). Observe: `kubectl -n slh-dev get pods`, `kubectl -n slh-dev rollout status deploy/order-service`.
3. Roll back the *GitOps way*: in the GitOps repo `git revert <the bot commit>` and push. ArgoCD restores the previous tag.
   (Emergency alternative: ArgoCD → app → **History and Rollback**; but remember a self-healing app will re-sync to git, so revert git afterwards.)
4. Fix the code in the app repo and ship again.

### D. Self-heal and drift detection
```bash
kubectl -n slh-dev scale deploy/user-service --replicas=5     # manual change = "drift"
kubectl -n slh-dev get pods -w                                 # ArgoCD reverts it to 1 within moments
```
Try it on `slh-prod` too: it shows **OutOfSync** but does **not** revert (no auto-sync there) — discuss why that is a deliberate choice.

### E. Configuration change through git only
Change `ONLINE_PAYMENT_LIMIT` for `payment-service` (add `- name: ONLINE_PAYMENT_LIMIT` / `value: "100"` to the env list in `base/payment-service.yaml`),
commit to the GitOps repo, watch the rollout, then place a UPI order above ₹100 → order status `PAYMENT_FAILED`. COD still works.
(Use `overlays/dev` with a kustomize patch if you want it dev-only.)

### F. Prune and namespace lifecycle
Remove `frontend.yaml` from `base/kustomization.yaml`, commit → ArgoCD **prunes** the Deployment/Service from dev/staging.
Revert the commit → they come back. This is what `prune: true` means.

### G. Autoscaling in prod
Install metrics-server (kind needs an extra flag — see [section 11](#11-production-hardening-checklist)), sync prod, then:
```bash
kubectl -n slh-prod get hpa
```
Generate load against `order-service` (e.g. `hey` or a busy loop of curl) and watch replicas go 2 → 5.

### H. Database operations (see section 8)
Connect with `psql`, inspect tables, take a backup, restore, change an order status by hand.

---

## 8. Database

### How it works here
* One PostgreSQL **StatefulSet** (`postgres-0`) with a 1 GiB **PersistentVolumeClaim** per environment, so data survives pod restarts/redeploys.
* On the **first** start of an empty volume, Postgres runs `init.sql` from the `postgres-initdb` ConfigMap → creates `userdb`, `restaurantdb`, `orderdb`, `paymentdb`.
* **Database-per-service**: each microservice owns its data and connects only to its own database (`DB_NAME` env var). Services never read each other's tables — `order-service` asks `restaurant-service` over HTTP for prices and `payment-service` over HTTP to charge.
* Each service creates its own tables on startup (`CREATE TABLE IF NOT EXISTS`) guarded by a Postgres advisory lock, so 2 replicas starting simultaneously don't collide. `restaurant-service` also seeds three restaurants when its table is empty.
* Credentials come from the `slh-secrets` Secret; host/port from the `slh-config` ConfigMap. The readiness probe (`/ready`) only turns green after the DB is reachable and tables exist, so traffic is never sent to a pod that can't talk to the database.
* Each environment (namespace) has its **own** Postgres and data — dev experiments can never touch prod data.

### Use it
```bash
# open a SQL shell in dev
kubectl -n slh-dev exec -it postgres-0 -- psql -U slhadmin -d orderdb
#   \dt                       list tables
#   SELECT id,status,total_amount FROM orders ORDER BY id DESC LIMIT 5;
#   UPDATE orders SET status='OUT_FOR_DELIVERY' WHERE id=1;     -- simulate the kitchen/rider workflow

# list all databases
kubectl -n slh-dev exec -it postgres-0 -- psql -U slhadmin -d postgres -c '\l'

# connect from your laptop's GUI tool (DBeaver, pgAdmin)
kubectl -n slh-dev port-forward pod/postgres-0 5432:5432     # host=localhost port=5432 user=slhadmin
# password (random, from the Secret):  kubectl -n slh-dev get secret slh-secrets -o jsonpath='{.data.DB_PASSWORD}' | base64 -d

# backup / restore
kubectl -n slh-dev exec postgres-0 -- pg_dump -U slhadmin orderdb > orderdb-$(date +%F).sql
cat orderdb-2026-11-01.sql | kubectl -n slh-dev exec -i postgres-0 -- psql -U slhadmin -d orderdb
```

### Things to know about this setup
* **Data survives** pod deletion and redeploys. It is **lost** if you delete the PVC or the namespace (`prune`/deleting the ArgoCD app with its finalizer removes the namespace objects; PVCs from StatefulSet templates are not auto-deleted, but don't rely on that).
* `init.sql` only runs on an **empty** volume. Editing the ConfigMap later does not create new databases; create them manually.
* Editing the seed list in `restaurant-service/server.js` does not change an already-seeded database — the seed runs only when the table is empty. Update rows with SQL (or wipe the volume in dev).
* Changing a ConfigMap does not restart pods by itself. Use `kubectl -n slh-dev rollout restart deploy/<name>` (or kustomize `configMapGenerator`, which adds a content hash and triggers a rollout automatically).

### What changes in a real company
| Here | Real company |
|---|---|
| Postgres in a StatefulSet | **Managed DB** (AWS RDS/Aurora, Azure Database for PostgreSQL, GCP Cloud SQL): automated backups, point-in-time recovery, multi-AZ failover, patching. Set `DB_HOST` in the ConfigMap to the managed endpoint and remove `postgres.yaml` from that environment. |
| One superuser for every service | **One DB role per service** with least privilege (`user_svc` can only touch `userdb`). |
| Tables created at app start | **Schema migrations** (Flyway / Liquibase / Prisma / node-pg-migrate) run as a pipeline step or Kubernetes Job / ArgoCD **PreSync hook**, versioned in git, reviewed in PRs. |
| Manual `pg_dump` | Scheduled backups (CronJob → object storage, or managed snapshots) + **tested restores**. |
| Same data model in every env | Prod data never copied to dev unless anonymised. |
| Secret in git | **Sealed Secrets** (this edition, [section 9](#9-secrets-management-with-sealed-secrets)) or an external vault (see the sibling External Secrets edition). |

---

## 9. Secrets management with Sealed Secrets

### 9.1 The rules every company follows
1. **A secret value never lives in git in plain text** (not in manifests, not in `docker-compose`, not in CI logs). If one leaks, assume it is compromised and rotate it.
2. **Every environment has different secrets.** A leaked dev password must not open prod.
3. **Humans do not know production passwords.** They are generated randomly by tooling and only the running application reads them.
4. **Access is least-privilege and auditable**, and secrets can be **rotated** without rebuilding images.

The basic project broke rule 1 on purpose (`base/secret.yaml`) so you could get running quickly. **This edition fixes it.** (`docker-compose.yml` keeps throwaway values such as `slhpassword` because it only runs on your own laptop; never reuse them anywhere real.)

### 9.2 How Sealed Secrets works
```mermaid
sequenceDiagram
  participant Dev as You / platform engineer
  participant KS as kubeseal CLI
  participant Git as GitOps repo
  participant Argo as ArgoCD
  participant Ctl as Sealed Secrets controller (in cluster)
  participant Pod as Your pods
  Ctl->>Ctl: generates a key PAIR on first start (private key stays in the cluster)
  Dev->>KS: plain Secret (random values, in memory)
  KS->>Ctl: fetch PUBLIC certificate
  KS-->>Dev: SealedSecret (encrypted, only this cluster + namespace + name can open it)
  Dev->>Git: commit sealed-secret.yaml (safe to be public)
  Argo->>Git: pull
  Argo->>Ctl: applies SealedSecret object
  Ctl->>Ctl: decrypts with PRIVATE key
  Ctl-->>Pod: creates normal Secret "slh-secrets" -> env vars
```
* **Encryption is one-way for you.** After sealing, nobody (not even you) can decrypt the file; only the controller holding the private key can.
* **Strict scope (default):** the ciphertext is bound to the secret's *name* and *namespace*. Copying a sealed file to another namespace does not work.
* The controller is an **operator**: it watches `SealedSecret` objects and keeps a matching `Secret` in sync.

### 9.3 What this edition changed
| File | Change |
|---|---|
| `shetty-lunch-home-gitops/base/secret.yaml` | **Deleted** (no plain secret in git any more) |
| `overlays/<env>/sealed-secret.yaml` | **New**, generated by you in step 8b, one per environment, different values |
| `overlays/<env>/kustomization.yaml` | Lists `sealed-secret.yaml` under `resources` (the script adds it) |
| `scripts/bootstrap.sh` | Also installs the Sealed Secrets controller (Helm) and **stops before** starting ArgoCD sync |
| `scripts/seal-secrets.sh` | **New**: generate random values + seal |
| `scripts/backup-sealing-key.sh` | **New**: export the private key for disaster recovery |
| `shetty-lunch-home-app/.github/workflows/ci.yml` | **New job `secret-scan`** (gitleaks) — fails/warns if a credential is committed |
| Deployments, Postgres, services | **No change.** They still read Secret `slh-secrets` (`DB_USER`, `DB_PASSWORD`, `JWT_SECRET`). |

### 9.4 Practice exercises (do them — this is what interviews ask)

**A. Prove the file is useless to a thief.**
```bash
kubectl create namespace scratch
sed 's/namespace: slh-dev/namespace: scratch/' overlays/dev/sealed-secret.yaml | kubectl apply -f -
kubectl -n scratch describe sealedsecret slh-secrets      # error: no key could decrypt secret
kubectl delete namespace scratch
```
Moving a sealed secret to another namespace (or another cluster) fails. That is the strict scope at work.

**B. Rotate the JWT secret (safe, no database involved).**
```bash
DBPASS=$(kubectl -n slh-dev get secret slh-secrets -o jsonpath='{.data.DB_PASSWORD}' | base64 -d)   # keep the current DB password
kubectl create secret generic slh-secrets --namespace slh-dev \
  --from-literal=DB_USER=slhadmin --from-literal=DB_PASSWORD="$DBPASS" --from-literal=JWT_SECRET="$(openssl rand -hex 32)" \
  --dry-run=client -o yaml | kubeseal --controller-name sealed-secrets-controller --controller-namespace kube-system --format yaml \
  > overlays/dev/sealed-secret.yaml
unset DBPASS
git add overlays/dev && git commit -m "rotate dev JWT secret" && git pull --rebase origin main && git push origin main
```
ArgoCD applies it and the controller updates the Secret. **Environment variables are only read when a pod starts**, so restart the consumers:
```bash
kubectl -n slh-dev rollout restart deploy/user-service deploy/order-service
```
All users must log in again (old tokens no longer verify). This is the "rotate secret" runbook.

**C. Rotate the database password (needs care — two places must change together).**
Postgres only reads `POSTGRES_PASSWORD` on its very first start, so changing the Secret alone breaks every service.
1. Generate a new password, e.g. `NEW=$(openssl rand -base64 24 | tr -d '/+=\n')`.
2. Change it **in Postgres first**: `kubectl -n slh-dev exec postgres-0 -- psql -U slhadmin -d postgres -c "ALTER USER slhadmin PASSWORD '$NEW'"`
   (inside the pod the local socket is trusted, so no old password is needed).
3. Re-seal exactly as in exercise B but with `DB_PASSWORD="$NEW"` (and the current JWT secret), commit, push.
4. `kubectl -n slh-dev rollout restart deploy` for the five app deployments. Existing connections keep working until restart.

Real teams avoid the brief window with *two* database users and swap them, or use Vault dynamic credentials / managed-DB IAM auth.

**D. Disaster recovery: lose the cluster, keep the key.**
```bash
kind delete cluster --name slh && ./scripts/bootstrap.sh      # fresh cluster = NEW private key
kubectl apply -f argocd/root-app.yaml                         # start GitOps again
kubectl -n slh-dev describe sealedsecret slh-secrets          # after applying root app: "no key could decrypt" - your git files are now dead
kubectl apply -f sealed-secrets-master-key.backup.yaml        # restore the OLD private key
kubectl -n kube-system rollout restart deploy/sealed-secrets-controller
kubectl -n slh-dev get secret slh-secrets                     # decrypted again, no re-sealing needed
```
This is why the key backup in step 8c is **not optional**. (Without a backup you re-run `FORCE=1 ./scripts/seal-secrets.sh all` and then must also re-align the database passwords as in C.)

**E. Catch a leak.** On a throw-away branch of the app repo add a line like `AWS_SECRET_ACCESS_KEY=AKIAIOSFODNN7EXAMPLEwJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY` to a file and open a PR.
Watch the `secret scan (gitleaks)` job report it. (It is report-only while practising; remove `continue-on-error: true` in `ci.yml` to make it block the pipeline.) Delete the branch afterwards.

### 9.5 Habits real teams follow with Sealed Secrets
* **Back up the controller's private key** and store it in a vault / password manager. The controller auto-generates a *new* key about every 30 days and keeps the old ones, so old sealed files keep working; back the keys up again after renewals.
* **Never `kubectl create secret` by hand** in a GitOps cluster; everything goes through a sealed file in a pull request, reviewed like code.
* **One sealed file per environment, different values.** Prod sealing should be done by a small, trusted group.
* **Restrict who can read Secrets** with Kubernetes RBAC (`get secrets` is as powerful as reading the password), and enable **etcd encryption at rest** (managed clouds do this by default).
* Keep the CI token (`GITOPS_PAT`) minimal and rotate it too. Run the gitleaks scan on every PR.

### 9.6 Limits of Sealed Secrets — why big companies often move to External Secrets Operator
* Rotation is manual (re-seal → PR → restart).
* No central view or **audit log** of who read which secret.
* You own key backup/restore; losing the key means re-sealing everything.
* The same value used by several clusters must be sealed once per cluster.

The sibling zip, **`shetty-lunch-home-external-secrets`**, implements the other approach with the same application so you can compare them side by side.

---

## 10. Moving to a real cloud

Same repos, same pipeline. What changes:

| Area | Local (kind) | Cloud (EKS / AKS / GKE) |
|---|---|---|
| Cluster | `kind create cluster` | Created with Terraform (`eks`/`aks`/`gke` module). Terraform code lives in a third repo (IaC). |
| Ingress | NodePort via kind port mappings | `ingress-nginx` Service of type `LoadBalancer` (or ALB / AGIC / GCE ingress) |
| DNS + TLS | `/etc/hosts`, HTTP | Route53/Cloud DNS records → the load balancer; **cert-manager + Let's Encrypt**; real hostnames in the overlay `patches` and `tls:` block on the Ingress |
| Registry | ghcr.io | ghcr.io still works; or ECR/ACR/GAR (change CI login step + image names) with cluster pull permissions via IAM roles (IRSA / Workload Identity) |
| Database | StatefulSet | RDS/Cloud SQL (section 8) |
| Storage class | kind default | `gp3`/`managed-csi`/`pd-balanced` via `storageClassName` |
| Secrets | sealed secrets sealed with the kind cluster's key | Seal again per cluster (or move to External Secrets with a cloud secrets manager); back up each cluster's key |
| ArgoCD access | port-forward | Ingress + SSO (OIDC/GitHub/Okta), RBAC per team |
| Clusters | 1 cluster, 3 namespaces | Usually separate clusters (nonprod / prod), registered in ArgoCD; change `destination.server` per Application |

---

## 11. Production hardening checklist

Not included (to keep practice manageable) but expected in real projects — good "next steps":

- [ ] **Observability**: Prometheus + Grafana (`kube-prometheus-stack`), `/metrics` via `prom-client`, Loki/ELK for logs, alerts (Alertmanager), uptime checks. Add tracing with OpenTelemetry.
- [ ] **NetworkPolicies**: default-deny; allow only frontend→services, order→restaurant/payment, services→postgres. (kind's default CNI doesn't enforce them; use Calico/Cilium.)
- [ ] **ResourceQuota / LimitRange** per namespace; **PodSecurity** `restricted` labels.
- [ ] **Argo Rollouts** for canary / blue-green releases with automatic analysis.
- [ ] **ArgoCD Notifications** (Slack/Teams on sync failed/degraded) and a GitHub webhook for instant sync.
- [ ] **Image signing** (cosign) + admission policy (Kyverno/OPA) + pin images by digest; Trivy on the built *images*, not just the repo, and make the scan blocking.
- [ ] **SonarQube/SAST**, dependency updates (Dependabot/Renovate), required status checks and CODEOWNERS on both repos.
- [ ] **Integration/e2e tests** in CI (compose or kind) and smoke tests after deploy (ArgoCD PostSync hook).
- [ ] **Per-service build filters** (only rebuild services whose folder changed) — currently all 5 images rebuild on every push.
- [ ] **Backups/DR**: scheduled DB backups, restore drills, multi-AZ.
- [ ] **ArgoCD ApplicationSet** to generate per-environment apps from one template; **ArgoCD Image Updater** as an alternative to CI committing tags.

**Optional: metrics-server on kind (needed for the prod HPA)**
```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
kubectl -n kube-system patch deployment metrics-server --type=json \
  -p '[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'
```

---

## 12. API reference

Base URL: `http://localhost:8080` (compose) or `http://dev.shettylunchhome.local` (cluster). Public endpoints go through the frontend nginx.

| Method & path | Auth | Purpose |
|---|---|---|
| `POST /api/users/register` | – | `{name,email,password,phone?,address?}` |
| `POST /api/users/login` | – | → `{token,user}` (JWT, 8 h) |
| `GET /api/users/:id` | Bearer | own profile only |
| `GET /api/restaurants` | – | list |
| `GET /api/restaurants/:id` | – | details |
| `GET /api/restaurants/:id/menu` | – | menu items |
| `POST /api/orders` | Bearer | `{restaurantId, items:[{menuItemId,quantity}], paymentMethod: COD\|UPI\|CARD, deliveryAddress}` → order with status `CONFIRMED` or `PAYMENT_FAILED` |
| `GET /api/orders` | Bearer | my orders |
| `GET /api/orders/:id` | Bearer | one order with items |
| `POST /api/orders/:id/cancel` | Bearer | cancel (PLACED/CONFIRMED/PAYMENT_FAILED) |
| `GET /health`, `GET /ready` | – | liveness / readiness on every service (internal) |
| `GET /api/menu-items/:id`, `POST /api/payments` | internal | **not** exposed through nginx/ingress on purpose |

```bash
BASE=http://localhost:8080
curl -s -X POST $BASE/api/users/register -H 'Content-Type: application/json' \
  -d '{"name":"Demo User","email":"demo@example.com","password":"secret123","address":"MG Road, Bengaluru"}'
TOKEN=$(curl -s -X POST $BASE/api/users/login -H 'Content-Type: application/json' \
  -d '{"email":"demo@example.com","password":"secret123"}' | python3 -c 'import sys,json;print(json.load(sys.stdin)["token"])')
curl -s $BASE/api/restaurants
curl -s $BASE/api/restaurants/1/menu
curl -s -X POST $BASE/api/orders -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"restaurantId":1,"items":[{"menuItemId":1,"quantity":2},{"menuItemId":3,"quantity":1}],"paymentMethod":"UPI","deliveryAddress":"MG Road, Bengaluru"}'
curl -s $BASE/api/orders -H "Authorization: Bearer $TOKEN"
```
Seeded menu item ids: restaurant 1 → 1-5, restaurant 2 → 6-10, restaurant 3 → 11-15.

---

## 13. Cleanup

```bash
kind delete cluster --name slh                 # removes the whole local cluster, ArgoCD, all data
cd shetty-lunch-home-app && docker compose down -v
```
GitHub: delete the two repos and the 5 packages if you no longer need them. Remove the hosts-file lines.

---

## 14. Troubleshooting

Method: **GitHub Actions → registry → GitOps repo commit → ArgoCD app status → pods → logs.** Find the first broken link.

| Symptom | Likely cause | Fix |
|---|---|---|
| CI `update-gitops` fails: *Input required: token* / `403` / `Repository not found` | `GITOPS_PAT` secret missing, expired, wrong repo scope, or the GitOps repo name differs | Redo step 6a; confirm repo is `<owner>/shetty-lunch-home-gitops` and has a `main` branch |
| CI `build & push` fails with `denied: permission_denied` | Workflow permissions read-only, or an existing package is owned by another repo | Settings → Actions → Workflow permissions → Read and write; package settings → manage Actions access |
| CI `test` fails: `Cannot find module` | dependencies not installed / lockfile out of sync | `npm install` in that service, commit the lockfile |
| Pods `ImagePullBackOff` / `ErrImagePull` | Package is private, tag doesn't exist yet, or username typo | Make packages public; `kubectl -n slh-dev describe pod <pod>`; check `newTag` exists in the Packages page. Private packages: `kubectl -n slh-dev create secret docker-registry ghcr --docker-server=ghcr.io --docker-username=<you> --docker-password=<PAT with read:packages>` and add `imagePullSecrets: [{name: ghcr}]` to each Deployment pod spec |
| ArgoCD app `ComparisonError` / `repository not found` / auth required | Repo is private or URL wrong | Make repo public, or ArgoCD UI → Settings → Repositories → Connect (HTTPS, username + PAT); verify `repoURL` in `argocd/*.yaml` |
| Argo app `Unknown` or *project not permitted* | `project.yaml` not applied, or namespace/repo not in project | `kubectl apply -f argocd/project.yaml`; compare `destinations`/`sourceRepos` |
| `slh-prod` is `OutOfSync` | **Expected** — manual sync | Press SYNC |
| Browser: `404 Not Found` from nginx | Wrong host header / host not in hosts file / ingress not ready | `kubectl -n slh-dev get ingress`; `curl -H "Host: dev.shettylunchhome.local" http://localhost/`; `kubectl -n ingress-nginx get pods` |
| Browser can't connect | Port 80 in use / Docker not mapping | Change `hostPort` in `kind-config.yaml`, recreate cluster (`kind delete cluster --name slh`) and use `:8081` |
| Pod `CrashLoopBackOff` | App error | `kubectl -n slh-dev logs <pod> --previous` |
| Pods Running but `0/1` Ready | `/ready` is 503: DB not reachable or init failed | `kubectl -n slh-dev logs deploy/user-service` → "db not reachable"; check `postgres-0` is Ready and `DB_HOST/DB_NAME/secret` match |
| `postgres-0` Pending | No storage class / PVC unbound | `kubectl -n slh-dev get pvc`; `kubectl get storageclass` (kind ships `standard`) |
| `postgres-0` error `initdb: directory exists but is not empty` | PGDATA must be a sub-directory of the mount | already set (`PGDATA=/var/lib/postgresql/data/pgdata`); delete the PVC if you changed it |
| `database "userdb" does not exist` | Volume was initialised before `init.sql` existed | `kubectl -n slh-dev exec -it postgres-0 -- psql -U slhadmin -d postgres -c 'CREATE DATABASE userdb;'` (or delete PVC in dev) |
| nginx frontend `host not found in upstream "order-service"` | Service for that name missing in the namespace | `kubectl -n slh-dev get svc`; all services must exist (they are in `base/`) |
| Order status `PAYMENT_FAILED` | Online payment above `ONLINE_PAYMENT_LIMIT` (default ₹20000) or payment-service down | Use COD / lower amount; check `payment-service` logs |
| `401 invalid or expired token` | `JWT_SECRET` differs between `user-service` and `order-service`, or token expired | Both read `slh-secrets/JWT_SECRET`; log in again |
| ArgoCD keeps reverting my `kubectl` change | `selfHeal: true` — by design | Change git instead |
| Bot commit conflicts with your GitOps commit | Both pushed to `main` | CI does `git pull --rebase` before pushing; just retry the failed job |
| `SealedSecret` status: *no key could decrypt secret* | Sealed by a different cluster, namespace or name (e.g. you rebuilt kind) | Restore the key backup (`kubectl apply -f sealed-secrets-master-key.backup.yaml` + restart the controller) or re-seal: `FORCE=1 ./scripts/seal-secrets.sh <env>` and align DB passwords (section 9.4 C) |
| `kubeseal: cannot fetch certificate ... services "sealed-secrets-controller" not found` | Controller not installed or named differently | `kubectl -n kube-system get deploy sealed-secrets-controller`; re-run `./scripts/bootstrap.sh` (installs it with `fullnameOverride`) |
| ArgoCD: *no matches for kind "SealedSecret"* | CRD missing: controller not installed before the sync | Install the controller (bootstrap step 3), then hard-refresh the app |
| Pods `CreateContainerConfigError`: `secret "slh-secrets" not found` | `sealed-secret.yaml` not pushed / not in the overlay / not decrypted | `kubectl -n slh-dev get sealedsecret,secret`; `kubectl -n kube-system logs deploy/sealed-secrets-controller`; check the overlay lists `sealed-secret.yaml` |
| Services log `password authentication failed for user "slhadmin"` after re-sealing | New random password in the Secret, old password still inside Postgres | `ALTER USER` in Postgres to the new password, restart pods (section 9.4 C) |
| `helm: command not found` / `kubeseal: command not found` | Tool not installed | See prerequisites |

Useful commands:
```bash
kubectl -n argocd get applications
kubectl -n argocd describe application slh-dev
kubectl -n slh-dev get all
kubectl -n slh-dev describe pod <pod>
kubectl -n slh-dev logs deploy/order-service -f
kubectl -n slh-dev get events --sort-by=.lastTimestamp
kubectl kustomize overlays/dev          # render exactly what ArgoCD will apply (needs kubectl ≥ 1.14)
```

---

## 15. Interview talking points

* *"Walk me through your CI/CD."* PR → CI tests/scans → image built once, tagged with the git SHA (immutable, never `latest` in deployments) → CI commits the tag to the GitOps repo → ArgoCD pulls and syncs → promotion between environments is a PR; prod needs approval and a manual sync.
* *"Why GitOps instead of `kubectl apply` from Jenkins?"* Git is the audit log, rollbacks are `git revert`, the cluster credentials never leave the cluster (pull model), drift is detected and healed.
* *"Why Kustomize overlays?"* One base, small per-environment differences (replicas, host, tag) — no copy-pasted manifests.
* *"How do services talk and what is public?"* Only the frontend is behind the ingress; nginx exposes just three API prefixes; menu-item lookup and payments are internal ClusterIP services. `order-service` never trusts prices from the browser.
* *"How do you handle the database?"* Database-per-service, PVC-backed StatefulSet for dev, managed DB + migrations + per-service roles in prod, secrets from a vault, backups and restore drills.
* *"What happens on a bad deploy?"* Readiness probes + rolling update keep the old pods serving; revert the GitOps commit; ArgoCD rolls back.
* *"How do you manage secrets in GitOps?"* Values never appear in git in plain text. I use **Sealed Secrets**: a controller in the cluster owns a private key, I encrypt with its public key, commit the `SealedSecret`, ArgoCD applies it and the controller turns it into a normal Secret. Strict scope binds it to one name/namespace/cluster, each environment has different random values, and I back up the controller key. For larger setups I would move to External Secrets Operator with a cloud secrets manager for central rotation and audit.
* *"What would you improve?"* Observability, NetworkPolicies, canary releases with Argo Rollouts, image signing, per-service pipelines, IaC for the cluster.

Happy practising! 🍛
